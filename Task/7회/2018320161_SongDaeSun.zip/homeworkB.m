function A=homeworkB(R)
global V
A=(((pi^2)*(R^4))+(9*(V^2)/(R^2)))^(1/2);
end