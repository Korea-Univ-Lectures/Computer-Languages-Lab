function A=homeworkA(r, V)
A=((pi^2)*(r.^4)+9*(V^2)./(r.^2)).^(1/2);